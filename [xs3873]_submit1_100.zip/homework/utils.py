from PIL import Image
import csv
import os
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms

LABEL_NAMES = ['background', 'kart', 'pickup', 'nitro', 'bomb', 'projectile']

class SuperTuxDataset(Dataset):
    """
    WARNING: Do not perform data normalization here. 
    """
    def __init__(self, dataset_path):

        #self.dataset_path = "/content/drive/MyDrive/Colab_Notebooks/ML_UTAustin/Homework2/DL_UT_HW2/"+ dataset_path
        self.dataset_path = dataset_path
        self.item_lst = []
        with open(self.dataset_path + '/labels.csv','r') as file:
          csv_reader = csv.reader(file)
          for row in csv_reader:
            item_name, item_label, _ = row
            self.item_lst.append([item_name, item_label])

        #raise NotImplementedError('SuperTuxDataset.__init__')

    def __len__(self):
        return len(self.item_lst)-1
        #raise NotImplementedError('SuperTuxDataset.__len__')

    def __getitem__(self, idx):
        item_name = self.item_lst[idx+1][0]
        item_label = self.item_lst[idx+1][1]
        # Read the image
        item_img = Image.open(self.dataset_path+"/"+item_name)
        #Convert image to tensor
        image_to_tensor = transforms.ToTensor()
        image_tensor = image_to_tensor(item_img)
        #Convert label to number
        label_int = LABEL_NAMES.index(item_label)
        return  image_tensor, label_int
        #raise NotImplementedError('SuperTuxDataset.__getitem__')


def load_data(dataset_path, num_workers=0, batch_size=128):
    dataset = SuperTuxDataset(dataset_path)
    return DataLoader(dataset, num_workers=num_workers, batch_size=batch_size, shuffle=True, drop_last=True)


def accuracy(outputs, labels):
    outputs_idx = outputs.max(1)[1].type_as(labels)
    return outputs_idx.eq(labels).float().mean()
