import torch
import torch.nn as nn
from torch.nn.modules import MaxPool2d, padding
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import torch.nn.functional as F
import math



class CNNClassifier(torch.nn.Module):
    def __init__(self):
      super().__init__()
      self.network = nn.Sequential(
          nn.Conv2d(3, 12, kernel_size=3, stride=1, padding=1),
          #nn.BatchNorm2d(16),
          nn.ReLU(),
          nn.MaxPool2d(kernel_size=2),
          nn.Conv2d(12, 32, kernel_size=3, stride=1, padding=1),
          #nn.BatchNorm2d(32),
          nn.ReLU(),
          nn.MaxPool2d(kernel_size=2),
          #nn.Flatten(),

          #raise NotImplementedError('CNNClassifier.__init__')
        )
      # self.relu = nn.ReLU()
      self.fc1 = nn.Linear(32*16*16,24) # 6 is the number of classes
      #self.fc2 = nn.Linear(24, 6)  # 6 is the number of classes
      self.drop = nn.Dropout2d(p = 0.2)
      self.flatten = nn.Flatten()
    def forward(self, x):

        
        x = self.network(x)
        x = self.drop(x)
        x = self.flatten(x)
        x = self.fc1(x)
        #x = self.fc2(self.fc1(x))
        #x = torch.softmax(x,dim=1)
        return x
        #raise NotImplementedError('CNNClassifier.forward')


def save_model(model):
    from torch import save
    from os import path
    if isinstance(model, CNNClassifier):
        return save(model.state_dict(), path.join(path.dirname(path.abspath(__file__)), 'cnn.th'))
    raise ValueError("model type '%s' not supported!"%str(type(model)))


def load_model():
    from torch import load
    from os import path
    r = CNNClassifier()
    r.load_state_dict(load(path.join(path.dirname(path.abspath(__file__)), 'cnn.th'), map_location='cpu'))
    return r
