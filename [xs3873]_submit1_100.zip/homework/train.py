from models import CNNClassifier, save_model
from utils import accuracy, load_data
import torch
import torch.utils.tensorboard as tb
import torch.nn as nn
import torch.optim as optim


def train(args):
    from os import path
    model = CNNClassifier()
    # train_logger, valid_logger = None, None
    # if args.log_dir is not None:
    #     train_logger = tb.SummaryWriter(path.join(args.log_dir, 'train'))
    #     valid_logger = tb.SummaryWriter(path.join(args.log_dir, 'valid'))

    """
    Your code here, modify your HW1 code
    
    """
    # model.train()
    
    #define training iteration number
    number_epochs = 200

    #Define valid data
    vali_data = load_data("data/valid")
    vali_x, vali_y = next(iter(vali_data))

    # Define loss function and optimizer
    criterion = nn.CrossEntropyLoss()
    learning_rate = 0.005
    #sgd_optimizer = optim.SGD(model.parameters(), lr=learning_rate, momentum=0.9)
    sgd_optimizer = optim.Adam(model.parameters(), lr=learning_rate)

    # start training
    for epoch in range(number_epochs):

      #load training data(every epoch get a new batch)
      train_data = load_data("data/train")
      train_x ,train_y = next(iter(train_data))

      #call model forward function and predict the labels of trainset
      pred_train = model(train_x)

      #Compute the loss of batch
      loss = criterion(pred_train, train_y)

      #calculate the accuracy
      pred_accuracy = accuracy(pred_train,train_y)

      #Zero the gradient descent
      sgd_optimizer.zero_grad()

      # Backpropagation, calculate the gradient of the parameters
      loss.backward()

      #Update all the parameters
      sgd_optimizer.step()

      print(f" For {epoch+1} / {number_epochs} Epoch, train loss is: {loss.item()}, train accuracy:{pred_accuracy}")




    save_model(model)


if __name__ == '__main__':
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--log_dir')
    # Put custom arguments here

    args = parser.parse_args()
    train(args)
